/*
 *  CEGEP de Saint-Hyacinthe
 */

package formatif1.tictactoe;

/**
 *
 * @author Stéphane
 */
public class PositionInvalide extends Exception{

}
