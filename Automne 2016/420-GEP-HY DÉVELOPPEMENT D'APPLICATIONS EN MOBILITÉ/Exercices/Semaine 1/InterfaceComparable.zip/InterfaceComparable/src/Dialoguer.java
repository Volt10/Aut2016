
public interface Dialoguer {

	public String parler();
}
