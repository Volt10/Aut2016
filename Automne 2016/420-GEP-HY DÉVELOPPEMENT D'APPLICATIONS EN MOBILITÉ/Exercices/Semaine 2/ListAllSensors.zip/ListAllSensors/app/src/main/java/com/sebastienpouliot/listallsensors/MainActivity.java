package com.sebastienpouliot.listallsensors;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText(this, "Je suis dans onCreate", Toast.LENGTH_SHORT).show();
        setContentView(R.layout.activity_main);

        this.findViewById(R.id.tSensorList);
        SensorManager sensorManager = (SensorManager)this.getSystemService(SENSOR_SERVICE);

        TextView content = (TextView)this.findViewById(R.id.tSensorList);
        content.setMovementMethod(new ScrollingMovementMethod());
        content.setText("Voici la liste des sensors : \n");

        List<Sensor> sensorList = sensorManager.getSensorList(Sensor.TYPE_ALL);
        for (Sensor s : sensorList)
            content.append(s.getName() + "\n");
    }

    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "Je suis dans onResume", Toast.LENGTH_SHORT).show();
    }

    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "Je suis dans onPause", Toast.LENGTH_SHORT).show();
    }
}
